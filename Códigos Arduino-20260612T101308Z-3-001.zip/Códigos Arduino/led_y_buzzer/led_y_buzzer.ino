using namespace std;

int ledPin = 13;
int buzzerPin = 8;
int switchPin;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(switchPin, INPUT_PULLUP); // activa pull-up interna
}

void loop() {
  digitalWrite(ledPin, HIGH); // LED siempre encendido

  if(digitalRead(switchPin) == LOW) {
    noTone(buzzerPin); // switch cerrado → apaga buzzer
  } else {
    tone(buzzerPin, 1000); // switch abierto → buzzer encendido
  }
}