#include <dht_nonblocking.h>  // Librería del Sensor TyH
#include <SoftwareSerial.h>   // Librería del Escáner

// ── Sensor de Temperatura y Humedad ──────────────────────────
#define DHT_SENSOR_TYPE DHT_TYPE_11
static const int DHT_SENSOR_PIN = 7;
DHT_nonblocking dht_sensor(DHT_SENSOR_PIN, DHT_SENSOR_TYPE);

// ── Escáner de Códigos de Barras ─────────────────────────────
SoftwareSerial scanner(10, 11);  // RX=10, TX=11
String codigo = "";

// ── Pines ─────────────────────────────────────────────────────
const int ledPin    = 13;
const int buzzerPin = 8;
const int switchPin = 2;   // IMPORTANTE: pon aquí el pin real de tu interruptor

// ── Variables TyH ─────────────────────────────────────────────
float temperatura = 0.0;
float humedad     = 0.0;

// ── Rangos recibidos desde Python ─────────────────────────────
// Valores por defecto mientras Python todavía no haya enviado nada
float tempMin = 0.0;
float tempMax = 50.0;
float humMin  = 20.0;
float humMax  = 90.0;

String lineaSerial = "";


// ── Procesar rangos recibidos desde Python ────────────────────
// Tu Python envía:
// tempMin,tempMax,humMin,humMax
//
// Ejemplo:
// 22.0,27.0,40.0,70.0

void procesarRangos(String linea) {
  linea.trim();

  int coma1 = linea.indexOf(',');
  int coma2 = linea.indexOf(',', coma1 + 1);
  int coma3 = linea.indexOf(',', coma2 + 1);

  if (coma1 == -1 || coma2 == -1 || coma3 == -1) {
    return;
  }

  float nuevaTempMin = linea.substring(0, coma1).toFloat();
  float nuevaTempMax = linea.substring(coma1 + 1, coma2).toFloat();
  float nuevaHumMin  = linea.substring(coma2 + 1, coma3).toFloat();
  float nuevaHumMax  = linea.substring(coma3 + 1).toFloat();

  // Validación básica
  if (nuevaTempMin >= nuevaTempMax || nuevaHumMin >= nuevaHumMax) {
    Serial.println("ERROR:RANGOS_INVALIDOS");
    return;
  }

  tempMin = nuevaTempMin;
  tempMax = nuevaTempMax;
  humMin  = nuevaHumMin;
  humMax  = nuevaHumMax;

  Serial.print("RANGOS_OK:");
  Serial.print(tempMin);
  Serial.print(",");
  Serial.print(tempMax);
  Serial.print(",");
  Serial.print(humMin);
  Serial.print(",");
  Serial.println(humMax);
}


// ── Leer rangos enviados por Python ───────────────────────────

void leerRangosPython() {
  while (Serial.available()) {
    char c = Serial.read();

    if (c == '\n' || c == '\r') {
      if (lineaSerial.length() > 0) {
        procesarRangos(lineaSerial);
        lineaSerial = "";
      }
    } else {
      lineaSerial += c;
    }
  }
}


void setup() {
  Serial.begin(9600);
  scanner.begin(9600);

  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(switchPin, INPUT_PULLUP);

  digitalWrite(ledPin, LOW);
  noTone(buzzerPin);
}


void loop() {

  // ── Leer rangos enviados desde Python ───────────────────────
  leerRangosPython();


  // ── Leer escáner de código de barras ────────────────────────
  while (scanner.available()) {
    char c = scanner.read();

    if (c == '\n' || c == '\r') {
      if (codigo.length() > 0) {
        Serial.print("ID:");
        Serial.println(codigo);
      }
      codigo = "";
    } else {
      if (codigo.length() < 16) {
        codigo += c;
      }
    }
  }


  // ── Leer sensor TyH ─────────────────────────────────────────
  if (dht_sensor.measure(&temperatura, &humedad)) {

    // Formato que tu Python entiende:
    // DATA:@temperatura/humedad
    Serial.print("@");
    Serial.print(temperatura);
    Serial.print("/");
    Serial.println(humedad);

    // Comparación con los rangos que llegan desde Python
    bool temperaturaFueraDeRango = (temperatura < tempMin || temperatura > tempMax);
    bool humedadFueraDeRango     = (humedad < humMin  || humedad > humMax);

    bool alarma = (temperaturaFueraDeRango || humedadFueraDeRango);

    if (alarma) {
      digitalWrite(ledPin, HIGH);

      // Si el interruptor está activado, silencia solo el buzzer
      if (digitalRead(switchPin) == LOW) {
        noTone(buzzerPin);
      } else {
        tone(buzzerPin, 1000);
      }

    } else {
      digitalWrite(ledPin, LOW);
      noTone(buzzerPin);
    }
  }
}


