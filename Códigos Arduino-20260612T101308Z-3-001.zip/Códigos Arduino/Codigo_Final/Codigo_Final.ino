#include <dht_nonblocking.h>  // Librería del Sensor TyH
#include <SoftwareSerial.h>   // Librería del Escáner

using namespace std;

// ── Sensor de Temperatura y Humedad ──────────────────────────
#define DHT_SENSOR_TYPE DHT_TYPE_11
static const int DHT_SENSOR_PIN = 7;
DHT_nonblocking dht_sensor(DHT_SENSOR_PIN, DHT_SENSOR_TYPE);

// ── Escáner de Códigos de Barras ─────────────────────────────
SoftwareSerial scanner(10, 11);  // RX=10, TX=11
String codigo = "";
// ── Pines ─────────────────────────────────────────────────────
int ledPin     = 13;
int buzzerPin  = 8;
int switchPin;

// ── Variables TyH ─────────────────────────────────────────────
float temperatura = 0.0;
float humedad     = 0.0;

void setup() {
  Serial.begin(9600);
  scanner.begin(9600);

  pinMode(ledPin,    OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(switchPin, INPUT_PULLUP);
}

void loop() {

  // ── Leer escáner ────────────────────────────────────────────
   while (scanner.available()) {
    char c = scanner.read();
    if (c == '\n' || c == '\r') {
      if (codigo.length() > 0) {
        Serial.print("#");
        Serial.println(codigo);
      }
      codigo = "";
    } else {
      if (codigo.length() < 16) {
      codigo += c;
      }
    }
  }

  // ── Leer sensor TyH ─────────────────────────────────────────
  if (dht_sensor.measure(&temperatura, &humedad)) {
    Serial.print("@");
    Serial.print(temperatura);
    Serial.print("/");
    Serial.println(humedad);

    if ((temperatura >= 22 && temperatura <= 27) || (humedad >= 1000 && humedad <= 20000)) {
      digitalWrite(ledPin, HIGH);

      if (digitalRead(switchPin) == LOW) {
        noTone(buzzerPin);      // Interruptor activado → silencio
      } else {
        tone(buzzerPin, 1000);  // Encender Buzzer
      }
    } else {
      noTone(buzzerPin);
      digitalWrite(ledPin, LOW);
    }    
    }
  }

